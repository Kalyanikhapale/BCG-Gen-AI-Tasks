# chatbot.py
import pandas as pd

# Load dataset
df = pd.read_csv(r"C:\Users\kalya\Downloads\financial_chatbot\financial_data.csv")  # Make sure this CSV is in the same folder as chatbot.py

# Function to answer queries
def financial_chatbot(query):
    query = query.lower()

    # Example queries
    if "apple" in query and "2024" in query and "total revenue" in query:
        revenue = df.loc[(df['Company'] == 'Apple') & (df['Fiscal Year'] == 2024), 'Total Revenue'].values[0]
        return f"Apple's total revenue in 2024 was {revenue:,} million USD."

    elif "microsoft" in query and "net income change" in query:
        net_2024 = df.loc[(df['Company'] == 'Microsoft') & (df['Fiscal Year'] == 2024), 'Net Income'].values[0]
        net_2023 = df.loc[(df['Company'] == 'Microsoft') & (df['Fiscal Year'] == 2023), 'Net Income'].values[0]
        change = net_2024 - net_2023
        percent_change = (change / net_2023) * 100
        return f"Microsoft's net income changed by {change:,} million USD ({percent_change:.2f}%) from 2023 to 2024."

    elif "tesla" in query and "liabilities/assets" in query and "2023" in query:
        ratio = df.loc[(df['Company'] == 'Tesla') & (df['Fiscal Year'] == 2023), 'Liabilities/Assets (%)'].values[0]
        return f"In 2023, Tesla's liabilities-to-assets ratio was {ratio}%."

    else:
        return "Sorry, I can only answer predefined queries like:\n" \
               "- 'What is Apple total revenue in 2024?'\n" \
               "- 'Net income change for Microsoft'\n" \
               "- 'Tesla liabilities/assets 2023'"

# Main chatbot loop
if __name__ == "__main__":
    print("Welcome to the Financial Chatbot! Type 'exit' to quit.")
    while True:
        user_input = input("You: ")
        if user_input.lower() == "exit":
            print("Chatbot: Goodbye!")
            break
        print("Chatbot:", financial_chatbot(user_input))
