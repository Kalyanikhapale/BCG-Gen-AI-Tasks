from flask import Flask, render_template, request
import pandas as pd

app = Flask(__name__)

# Load your dataset
df = pd.read_csv(r"C:\Users\kalya\Downloads\financial_chatbot\financial_data.csv")

# Simple function for responding to queries
def get_response(query):
    query = query.lower()

    if "total revenue" in query:
        total_revenue = df["Total Revenue"].sum()
        return f"The total revenue across all years and companies is {total_revenue:,} million USD."

    elif "net income change" in query:
        apple_df = df[df["Company"] == "Apple"].sort_values("Fiscal Year")
        change = apple_df.iloc[-1]["Net Income Growth (%)"]
        return f"Apple's net income changed by {change:.2f}% compared to last year."

    elif "highest revenue" in query:
        latest_year = df["Fiscal Year"].max()
        latest_df = df[df["Fiscal Year"] == latest_year]
        top_company = latest_df.loc[latest_df["Total Revenue"].idxmax()]
        return f"In {latest_year}, {top_company['Company']} had the highest revenue: {top_company['Total Revenue']:,} million USD."

    else:
        return "Sorry, I can only respond to: 'total revenue', 'net income change', 'highest revenue'."

@app.route("/", methods=["GET", "POST"])
def home():
    response = ""
    if request.method == "POST":
        user_query = request.form["query"]
        response = get_response(user_query)
    return render_template("index.html", response=response)

if __name__ == "__main__":
    app.run(debug=True)
